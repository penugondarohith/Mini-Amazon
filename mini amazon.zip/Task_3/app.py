from flask import Flask,render_template,request,url_for,redirect
from flask_sqlalchemy import SQLAlchemy

from flask_bcrypt import Bcrypt 
app=Flask(__name__)
app.secret_key = "Dileep66$"
bcrypt = Bcrypt(app)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///cart.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    model = db.Column(db.String(200))
    pic = db.Column(db.String)  # Corrected BLOB data type
    sal = db.Column(db.Integer) 
class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(200))
    noi=db.Column(db.Integer)
    total=db.Column(db.Integer)
    status=db.Column(db.Integer,nullable=True)

class register(db.Model):
    
    email = db.Column(db.String(200),primary_key=True)
    password = db.Column(db.String(200),nullable=False)

    def __repr__(self):
        return f"{self.email}-{self.password}"   
with app.app_context():
    db.create_all()
@app.route('/',methods=['POST','GET'])
def login():
    if request.method=="POST":
            email= request.form['email']
            password = request.form['password']
            if email=="admin263@gmail.com" and password=="admin06":
                return redirect('/admin')
            else:
                reg=register.query.filter_by(email=email).first()
                if reg==None:
                    messagee="You are not registered"
                    return render_template('login.html',message=messagee)
        
                re_pass = reg.password
                is_valid = bcrypt.check_password_hash(re_pass,password)
                if is_valid:
                    print(email)
                    return render_template('index.html',email=email)
                else:
                    messagee="You entered incorect Password "
                    return render_template('login.html',message=messagee)
    return render_template('login.html')
@app.route('/register',methods=['POST','GET'])
def regist():
    if request.method=="POST":
        email=request.form['email']
        password =request.form['password']
        req_password=request.form['re_password']
        if password==req_password:
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8') 
            regi=register(email=email,password=hashed_password)
            db.session.add(regi)
            db.session.commit()
            msg="You are registered"
            return render_template('login.html',success=msg)
        else:
            messagee="Incorrect password Please give correct details"
            
            return render_template('register.html',message=messagee)
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    return render_template('index.html')
@app.route('/order', methods=['POST', 'GET'])
def order():
        email=request.form['email']
        noi=request.form['noi']
        total=request.form['total']
        new_order=Order(email=email,noi=noi,total=total,status="Under Review")
        db.session.add(new_order)
        db.session.commit()
        items = Order.query.filter_by(email=email).all() 
        return render_template('user_review.html',items=items)
@app.route('/order_details')
def order_details():
    admin="admin263@gmail.com"
    items = Order.query.all()
    return render_template('order_details.html',items=items,admin=admin)
@app.route('/cart/<string:email>', methods=['POST', 'GET'])
def goog(email):
    if request.method=='POST':
        model_name = request.form.get("model", "")  # Get model name safely
        image_path = request.form.get("pic", "")    # Get image path safely
        pri = request.form.get("sal", "₹0")  # Default to ₹0 if not found

        # Ensure the price is an integer
        pri = int(pri[1:])  
        print(pri)
        # Insert into database with email association
        new_item = Cart(model=model_name, pic=image_path, sal=pri)
        db.session.add(new_item)
        db.session.commit()
        return render_template('index.html',email=email)

    return redirect(f'/cart/{email}')  # Correct redirection

@app.route("/cart_view/<string:email>", methods=["GET","POST"])
def view_cart(email):
    items = Cart.query.all()
    return render_template("cart.html", items=items,email=email)
@app.route("/delete/<int:id>/<string:email>", methods=["GET","POST"])
def delete(id,email):
    item=Cart.query.filter_by(id=id).first()
    db.session.delete(item)
    db.session.commit()
    return redirect(f'/cart_view/{email}')
@app.route("/delete_order/<int:id>", methods=["GET","POST"])
def delete_order(id):
    item=Order.query.filter_by(id=id).first()
    if item.status=="Under Review":
        item.status="Rejected"
    db.session.commit()
    return redirect(url_for('admin'))
@app.route("/accept_order/<int:id>", methods=["GET","POST"])
def accept_order(id):
    item=Order.query.filter_by(id=id).first()
    if item.status=="Under Review":
        item.status="Accepted"
    db.session.commit()
    return redirect(url_for('admin'))  
@app.route('/history/<string:email>')
def user_history(email):
    items = Order.query.filter_by(email=email).all()  # Fetch all orders related to the email
    return render_template("user_review.html",items=items,email=email)
@app.route('/history')
def admin_history(email):
    items = Order.query.all()  # Fetch all orders related to the email
    return render_template("user_review.html")
@app.route('/admin')
def admin():
    return redirect('/order_details')
if __name__=="__main__":
    app.run(debug=True)